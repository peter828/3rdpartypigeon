---
layout: "journal_by_tag"
tag: "tag02"
permalink: "/journal/tag/tag02/"
header-img: "img/archive-bg.jpg"
---