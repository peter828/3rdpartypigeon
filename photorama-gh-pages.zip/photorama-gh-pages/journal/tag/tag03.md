---
layout: "journal_by_tag"
tag: "tag03"
permalink: "/journal/tag/tag03/"
header-img: "img/archive-bg.jpg"
---